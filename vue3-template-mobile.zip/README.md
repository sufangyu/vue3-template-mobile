# vue3-template-mobile

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


## Q&A

### error Command "husky-run" not found.
See [husky改yorkie遇到的问题](https://blog.csdn.net/yuu2lee4/article/details/115181432).
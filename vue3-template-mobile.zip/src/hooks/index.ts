import useVuexValue from './use-vuex-value';

export {
  useVuexValue,
};

import WhiteSpace from './white-space';

export default WhiteSpace;

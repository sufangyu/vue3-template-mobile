import WingBlank from './wing-blank';

export default WingBlank;

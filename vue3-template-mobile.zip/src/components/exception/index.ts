import Exception from './exception.vue';

export default Exception;

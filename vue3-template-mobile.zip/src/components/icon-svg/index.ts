import IconSvg from './icon-svg.vue';

export default IconSvg;

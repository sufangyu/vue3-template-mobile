/** 通用对象 */
export interface BaseObject {
  [key: string]: any;
}
